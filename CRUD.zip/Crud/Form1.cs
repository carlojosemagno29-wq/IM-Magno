﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Crud
{
    public partial class Form1 : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;database=motorcycle_shop_db;uid=root;pwd=Carlo05371946;");
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (username == "" || password == "")
            {
                lblMessages.Text = "Please enter both username and password.";
                lblMessages.ForeColor = System.Drawing.Color.Red;
                return;
            }

            try
            {
                conn.Open();
                string query = "SELECT * FROM users WHERE Username=@user AND Password=@pass";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", username);
                cmd.Parameters.AddWithValue("@pass", password);
                MySqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string fullname = reader["FullName"].ToString();
                    MessageBox.Show("Welcome, " + fullname + "!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                    conn.Close();
                    this.Hide();

                    Form2 mainForm = new Form2();
                    mainForm.Show();
                }
                else
                {
                    lblMessages.Text = "          Invalid username or password.";
                    lblMessages.ForeColor = System.Drawing.Color.Red;
                }

                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to database:\n" + ex.Message);
                conn.Close();
            }
        }
    }
}
